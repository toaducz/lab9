using StudentService;
using static System.Formats.Asn1.AsnWriter;

namespace StudentTest
{
    [TestClass]
    public class StudentTest
    {
       
        [TestMethod]
        [ExpectedException(typeof(SystemException))]
        public void scoreOver10_should_ThrowException()
        {
            Student student2 = new Student { Score = 11 };
          

        }
        [TestMethod]
        [ExpectedException(typeof(SystemException))]
        public void scoreUnder0_should_ThrowException()
        {
            Student student2 = new Student { Score = -12 };
        }
       
      



        [DataRow(8.0)]
        [DataRow(9.0)]
        [DataRow(10.0)]
        [TestMethod]
        public void getLetterScoreA(double a)
        {
            Student student2 = new Student { Id = 12, Age = 19, Name = "Nam", Score = a };
            char temp = student2.getLetterScore();
            bool letter = false;
            if(temp == 'A')
            {
                letter = true;
            }
            Assert.IsTrue(letter);
        }
        [DataRow(7.0)]
        [DataRow(7.5)]
        [DataRow(7.99)]
        [TestMethod]
        public void getLetterScoreB(double b)
        {
            Student student2 = new Student { Id = 12, Age = 19, Name = "Nam", Score = b };
            char temp = student2.getLetterScore();
            bool letter = false;
            if (temp == 'B')
            {
                letter = true;
            }
            Assert.IsTrue(letter);
        }

        [DataRow(5.0)]
        [DataRow(6.5)]
        [DataRow(6.99)]
        [TestMethod]
        public void getLetterScoreC(double c)
        {
            Student student2 = new Student { Id = 12, Age = 19, Name = "Nam", Score = c };
            char temp = student2.getLetterScore();
            bool letter = false;
            if (temp == 'C')
            {
                letter = true;
            }
            Assert.IsTrue(letter);
        }
        [DataRow(4.9)]
        [DataRow(4.0)]
        [DataRow(3.5)]
        [TestMethod]
        public void getLetterScoreD(double a)
        {
            Student student2 = new Student { Id = 12, Age = 19, Name = "Nam", Score = a };
            char temp = student2.getLetterScore();
            bool letter = false;
            if (temp == 'D')
            {
                letter = true;
            }
            Assert.IsTrue(letter);
        }
    }
}