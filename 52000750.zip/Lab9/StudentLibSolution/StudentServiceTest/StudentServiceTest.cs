using StudentService;
namespace StudentServiceTest
{
    [TestClass]
    public class StudentServiceTest
    {
        [TestMethod]
        public void addStudent_should_increaseSizetoOne()
        {
            StudentService.StudentService student = new StudentService.StudentService();
            Student student2 = new Student { Name = "nam",Id=12,Age = 19, Score = 5.0 };
     
            bool temp = student.addStudent(student2);
            Assert.IsTrue(temp);
            Assert.AreEqual(1,student.size());
        }
        [TestMethod]
        public void addStudentFail_should_returnFalse()
        {
            StudentService.StudentService student = new StudentService.StudentService();
            Student student2 = new Student { Name = "nam", Id = 12, Age = 19, Score = 5.0 };
            Student student3 = new Student { Name = "nam", Id = 12, Age = 19, Score = 5.0 };
            student.addStudent(student2);
            bool temp = student.addStudent(student3);
            Assert.IsFalse(temp);
           
        }
        [TestMethod]
        public void addStudentDuplicate_should_fail()
        {
            StudentService.StudentService student = new StudentService.StudentService();
            Student student2 = new Student { Name = "nam", Id = 12, Age = 19, Score = 5.0 };
            Student student3 = new Student { Name = "nam", Id = 12, Age = 19, Score = 5.0 };
            student.addStudent(student2);
            student.addStudent(student3);
            Assert.AreEqual(1, student.size());

        }

        [TestMethod]
        [ExpectedException(typeof(NullReferenceException))]
        public void addStudentNull_should_thrownException()
        {
            StudentService.StudentService student = new StudentService.StudentService();
            student.addStudent(null);
        }

    }
}